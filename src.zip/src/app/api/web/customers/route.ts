import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";
import { normalizePhoneToE164 } from "@/lib/phone";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const q = (searchParams.get("q") || "").trim();

  if (!q || q.length < 2) {
    return NextResponse.json({ customers: [] }, { status: 200 });
  }

  // si parece teléfono, lo normalizamos y buscamos por e164 exacto
  const looksPhone = /[0-9+()\-.\s]/.test(q) && q.replace(/\D/g, "").length >= 6;
  let phoneE164: string | null = null;

  if (looksPhone) {
    const n = normalizePhoneToE164(q, "MX");
    phoneE164 = n.e164;
  }

  let query = supabaseAdmin
    .from("customers")
    .select("id, full_name, phone_e164, created_at")
    .limit(8)
    .order("created_at", { ascending: false });

  if (phoneE164) {
    query = query.eq("phone_e164", phoneE164);
  } else {
    // búsqueda por nombre (simple y efectiva)
    query = query.ilike("full_name", `%${q}%`);
  }

  const { data, error } = await query;

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ customers: data ?? [] }, { status: 200 });
}
